/* eslint-disable import/no-cycle */
import { el } from 'redom';
import { gsap } from 'gsap';
import { getEvents } from './api';
import { DB, baseUrl } from './creator';

import 'normalize.css';
import '../style.sass';

export const screen = el('div.screen');
export const bottom = el('div.screen__bottom');
export const areaLinks = el('div.screen__bottom__links');
export const heading = el('h1.screen__heading', 'text');
export const chat = el('div.screen__chat');
export const chatBody = el('div.screen__chat__body');
export const areaStreams = el('div.screen__chat__streams');
export const links = [
  DB.links.fansly,
  DB.links.onlyFans,
  DB.links.snapChat,
  DB.links.instagram,
  DB.links.twitter,
];

export const streams = {
  chaturbate: DB.streams.chaturbate.element,
};

export function start() {
  links.forEach((e) => {
    areaLinks.append(e);
  });

  for (const e in streams) {
    if (Object.hasOwnProperty.call(streams, e)) {
      areaStreams.append(streams[e]);
    }
  }

  bottom.append(areaLinks);
  chat.append(chatBody, areaStreams);
  screen.append(heading, bottom, chat);
  document.body.append(screen);

  getEvents(baseUrl);
}
