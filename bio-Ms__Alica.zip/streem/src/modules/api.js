/* eslint-disable import/no-cycle */
import { streams } from './screen';
import { ACTIVE } from './creator';

// eslint-disable-next-line import/prefer-default-export
export function getEvents(url) {
  fetch(url).then((response) => response.json())
    .then((jsonResponse) => {
      // Process messages
      for (const message of jsonResponse.events) {
        const { method } = message;
        const { object } = message;
        // console.log(`Message ID: ${message.id}`);
        if (method === 'broadcastStart') {
          if (!streams.chaturbate.classList.contains('on')) { streams.chaturbate.classList.add('on'); }
        } else if (method === 'broadcastStop') {
          if (streams.chaturbate.classList.contains('on')) { streams.chaturbate.classList.remove('on'); }
        } else if (method === 'userEnter') {
          ACTIVE.pushChatMessage(object);
        } else if (method === 'userLeave') {
          console.log(`${object.user.username} left the room`);
        } else if (method === 'follow') {
          console.log(`${object.user.username} has followed`);
        } else if (method === 'unfollow') {
          console.log(`${object.user.username} has unfollowed`);
        } else if (method === 'fanclubJoin') {
          console.log(`${object.user.username} joined the fan club`);
        } else if (method === 'chatMessage') {
          ACTIVE.pushChatMessage(object);
          console.log(object);
          console.log(`${object.user.username} sent chat message: ${object.message.message}`);
        } else if (method === 'privateMessage') {
          console.log(`${object.message.fromUser} sent private message to ${object.message.toUser}: ${object.message.message}`);
        } else if (method === 'tip') {
          console.log(`${object.user.username} sent ${object.tip.tokens} tokens ${object.tip.isAnon ? 'anonymously' : ''} ${object.tip.message ? `with message: ${object.tip.message}` : ''}`);
        } else if (method === 'roomSubjectChange') {
          console.log(`Room Subject changed to ${object.subject}`);
        } else if (method === 'mediaPurchase') {
          console.log(`${object.user.username} purchased ${object.media.type} set: ${object.media.name}`);
        } else {
          console.error('Unknown method:', method);
        }
      }

      // Once messages are processed, call getEvents again with 'nextUrl' to get new messages
      getEvents(jsonResponse.nextUrl);
    })
    .catch((err) => {
      console.error('Error:', err);
    });
}
