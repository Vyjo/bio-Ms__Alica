/* eslint-disable import/no-cycle */
import gsap from 'gsap';
import { chatBody } from './screen';

// eslint-disable-next-line import/prefer-default-export

export const broadcaster = 'vyjo';

export const CFT = (template) => {
  const element = document.createElement('template');
  element.innerHTML = template.trim();
  return element.content.firstChild;
};

export const ACTIVE = {
  getLinkElement(object) {
    return CFT(`
    <div class="screen__bottom__links__item" id="${object.name}">
      <img scr="${object.ico}">
      <p>${object.name}</p>
    </div>
    `);
  },
  getStreamCheckerElement(name) {
    return CFT(`
    <div class="screen__chat__streams__item on" id="streamOn-${name}"></div>
    `);
  },
  getChatMessage(object) {
    let tipName;
    if (object.user.username === broadcaster) {
      tipName = 'bro';
    } else if (object.user.inFanclub) {
      tipName = 'fan';
    } else if (object.user.isMod) {
      tipName = 'mod';
    } else if (object.user.recentTips) {
      tipName = object.user.recentTips;
    }
    return CFT(`
    <p class="screen__chat__item">
      <span class="${tipName}">${object.user.username}:</span>${object.message.message}
    </p>
    `);
  },
  pushChatMessage(method, object) {
    let e;
    if (method = 'chatMessage') {
      e = this.getChatMessage(object);
    } else if (method = 'userEnter') {
      e = this.getChatMessage(object);
    } else if (method = 'userLeave') {
      e = this.getChatMessage(object);
    } else if (method = 'follow') {
      e = this.getChatMessage(object);
    } else if (method = 'fanclubJoin') {
      e = this.getChatMessage(object);
    } else if (method = 'tip') {
      e = this.getChatMessage(object);
    }

    chatBody.prepend(e);
    setTimeout(() => { e.remove(); }, 10000);
  },
};

export const baseUrl = 'https://eventsapi.chaturbate.com/events/vyjo/v4cYe66ipEfUpJvSlMGjQ2Zh/';

export const DB = {
  links: {
    fansly: ACTIVE.getLinkElement({ name: 'fansly', ico: '' }),
    onlyFans: ACTIVE.getLinkElement({ name: 'OnlyFans', ico: '' }),
    snapChat: ACTIVE.getLinkElement({ name: 'Snapchat', ico: '' }),
    twitter: ACTIVE.getLinkElement({ name: 'twitter', ico: '' }),
    instagram: ACTIVE.getLinkElement({ name: 'instagram', ico: '' }),
  },
  streams: {
    chaturbate: {
      element: ACTIVE.getStreamCheckerElement('chaturbate'),
      name: 'chaturbate',
      link: '',
    },
  },
};

// gsap.from('.screen__chat__item', {
//   x: 400, ease: 'power3', opacity: 0,
// });
