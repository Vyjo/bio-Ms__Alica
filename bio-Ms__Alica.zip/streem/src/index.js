import { start } from './modules/screen';

start();
