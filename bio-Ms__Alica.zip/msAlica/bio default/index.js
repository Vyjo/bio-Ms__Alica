setTimeout(() => {
  const code = document.querySelector('.body')
  const codeCopy = document.querySelector('.def__btn')
  const codePlace = document.querySelector('.def__place')

  console.log(code.innerHTML);

  codePlace.textContent = code.innerHTML

  codeCopy.addEventListener('click', () => {
    navigator.clipboard.writeText(code.innerHTML)
    .then(() => {
      codeCopy.classList.add('success')
      setTimeout(() => {
        codeCopy.classList.remove('success')
      }, 300);
    })
    .catch(err => {
      console.log('Something went wrong', err);
    });
  })
}, 1000);

