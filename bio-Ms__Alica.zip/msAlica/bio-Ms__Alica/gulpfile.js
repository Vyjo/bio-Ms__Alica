const { series, src, dest } = require('gulp');
const sass = require('gulp-sass')(require('sass'));
const pug = require('gulp-pug');

const html = () => {
  return src('./src/*.pug')
    .pipe(
      pug({
        // Your options in here.
      })
    )
    .pipe(dest('./dist'));
};

const styles = () => {
  return src('./src/style.sass')
    .pipe(sass().on('error', sass.logError))
    .pipe(dest('./dist'));
}


exports.html = html;
exports.styles = styles;

exports.default = series( styles );
