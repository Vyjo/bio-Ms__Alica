import "normalize.css";
import "./style.sass";

import {sections} from "./modules/content";

const body = window.document.body

const header = sections.header
const main = sections.main;
const table = sections.table.clients

body.append(header, main)
main.append(table)
