import SpriteSymbol from 'svg-baker-runtime/browser-symbol';
// import BrowserSprite from 'svg-baker-runtime/src/browser-sprite';

// import vk from '../assets/img/svg/vk.svg'

// const sprite = new BrowserSprite();
// console.log(sprite);

// // const symbol = new SpriteSymbol(vk);
// // console.log(symbol);

// export default vk;

import BrowserSprite from 'svg-baker-runtime/src/browser-sprite';
import domready from 'domready';

const sprite = new BrowserSprite();
domready(() => sprite.mount('body'));

// import vk from '../assets/img/svg/vk.svg'
// const symbol = new SpriteSymbol(vk);
// sprite.add(vk)

export default sprite; // don't forget to export!
