import { el, svg } from "redom";
import { SVG } from "./collector";

export const GFTemplates = {
  // tabelHead(columns) {
  //   const element = el('.table__element__head')
  //   for (const key in columns) {
  //     if (!Object.hasOwnProperty.call(columns, key)) return
  //     let column = el('div.table__item__info')
  //     let name = el('p')
  //     if (columns[key].name) name.textContent = columns[key].name
  //     if (columns[key].sorting) name.append(el('span', {'data-sort': true}))
  //     if (columns[key].prompt) name.append(el('span', columns[key].prompt))
  //     column.append(name)
  //     element.append(column)
  //   }
  //   return element
  // },

}

export const GFCreateFromTemplate = template => {
  const element = document.createElement('template');
  element.innerHTML = template.trim();
  return element.content.firstChild;
}
