import { SVG } from "./collector";
import { GFCreateFromTemplate } from "./creator";

import HeaderElement from "./header/header";
import MainElement from "./main/main";
import TemplateSectionElement from "./sections/TemplateSectionElement";
import TableElement from "./tables/table";



export const content = {
  loading: GFCreateFromTemplate(`<div class="loading">${SVG.loadBig}</div>`),
  table: {
    name: "table",
    heading: "Клиенты",
    columns: {
      id: {
        name: 'ID',
        sorting: 'id',
        prompt: GFCreateFromTemplate(SVG.arrFull),
        active: () => {
          function fn(prompt) {
            prompt.classList.toggle('js-rev')
          }
          return fn
        }
      },
      surname: {
        name: 'Фамилия Имя Отчество',
        sorting: 'surname',
        prompt: 'А-я',
        active: () => {
          function fn(prompt) {
            if (prompt.textContent == 'А-я') {
              prompt.textContent = 'я-А'
            } else {prompt.textContent = 'А-я'}
            console.log(prompt);
          }
          return fn
        }
      },
      createdAt: {
        name: 'Дата и время создания',
        sorting: 'createdAt',
        prompt: GFCreateFromTemplate(SVG.arrFull),
        active: () => {
          function fn(prompt) {
            prompt.classList.toggle('js-rev')
          }
          return fn
        }
      },
      updatedAt: {
        name: 'Последние изменения',
        sorting: 'updatedAt',
        prompt: GFCreateFromTemplate(SVG.arrFull),
        active: () => {
          function fn(prompt) {
            prompt.classList.toggle('js-rev')

          }
          return fn
        }
      },
      contacts: {
        name: 'Контакты',
      },
      active: {
        name: 'Действия',
      },
    }
  },
};

const tableClients = new TableElement('table-contacts', content.table.columns)

export const sections = {
  header: new HeaderElement().element,
  main: new MainElement().element,
  table: {
    clients: new TemplateSectionElement(
      content.table.name,
      content.table.heading,
      tableClients.element
    ).element,
  },
  footer: undefined,
}

