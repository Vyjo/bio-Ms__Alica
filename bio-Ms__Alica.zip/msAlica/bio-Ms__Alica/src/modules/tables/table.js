import { el, } from "redom";
import "./table.sass";
import { GFCreateFromTemplate } from "../creator";
import { SVG, contactOptions } from "../collector";
import { api } from "../api";

export default class TableElement {
  constructor(id, columns) {
    this.id = id || '';
    this.columns = columns
    this.items = []
    this._sortToggle = {}
    this.data = []

    this._HTMLTemplates = {
      modal(object) {
        const modalType = { heading: 'Новый клиент', btnClose: `<button type="button" class="modal__form__bottom__cancel" data-btn="modalClose">Отмена</button>` }
        if (object.id) { modalType.heading = `Изменить данные  <span class="id">ID: ${object.id}</span>`; modalType.btnClose = `<button type="button" class="modal__form__bottom__cancel" data-btn="deleteItem">Удалить клиента</button>`}
        const modal = GFCreateFromTemplate(`
          <div class="modal anim-show" id='modal-${object.id || 'createPerson'}'>
            <div class="modal__bg" data-btn="modalHidden"></div>
            <div class="modal__box anim-drop">
              <form class="modal__form">
                <button class="modal__x" data-btn="modalClose">${SVG.union}</button>
                <div class="modal__form__inputs container">
                  <h3 class="modal__heading">${modalType.heading}</h3>

                  <div class="modal__form__input">
                    <h4>Фамилия <span>*</span></h4>
                    <input type="text" data-input="surname" data-validation name="surname" placeholder="Фамилия" value=${object.surname}>
                  </div>

                  <div class="modal__form__input">
                    <h4>Имя<span>*</span></h4>
                    <input type="text" data-input="name" data-validation name="name" placeholder="Имя" value=${object.name}>
                  </div>

                  <div class="modal__form__input">
                    <h4>Отчество</h4>
                    <input type="text" data-input="lastName" name="lastName" placeholder="Отчество" value=${object.lastName}>
                  </div>
                </div>

                <div class=" container modal__form__contacts">

                  <button type="button" class="modal__form__contacts__element modal__form__contacts__btn">${SVG.addSecondary} Добавить контакт</button>
                </div>

                <div class="modal__form__bottom modal__form__footer container">
                  <p class="modal__form__error" style="display: none"></p>
                  <button type="submit" value="Сохранить" class="btn btn-fill modal__form__bottom__submit" data-btn="formSubmit">Сохранить</button>
                  ${modalType.btnClose}
                </div>
              </form>
            </div>
          </div>
        `)
        const contactsArea = modal.querySelector('.modal__form__contacts')
        const btnAdd = modal.querySelector('.modal__form__contacts__btn')
        object.contacts ? object.contacts.forEach(contact => { (this.contactInput(contactsArea, contact))}) : undefined

        btnAdd.addEventListener('click', () => {
          this.contactInput(contactsArea)
          // баг: После переполнения элементов, и удаления лишнего, кнопка не появляется обратно
        })

        return {
          element: modal,
          contacts: contactsArea,
          buttons: modal.querySelectorAll('[data-btn]'),
          inputs: modal.querySelectorAll('[data-input]'),
          validation: modal.querySelectorAll('[data-validation]'),
          error: modal.querySelector('.modal__form__error'),
          form: modal.querySelector('form')
        }
      },
      modalDelete(object) {
        const modal = GFCreateFromTemplate(`
          <div class="modal anim-show" id='modalDelete-${object.id}'>
            <div class="modal__bg " data-btn="modalHidden"></div>
            <form class="modal__box anim-drop container">
              <button class="modal__x" data-btn="modalClose">${SVG.union}</button>
              <h3 class="modal__heading">Удалить клиента</h3>
              <p class="modal__txt">Вы действительно хотите удалить данного клиента?</p>
              <p class="modal__person">${object.surname} ${object.name} ${object.lastName} <span class="id"> ID: ${object.id}</span></p>

              <div class="modal__form__bottom">
                <button type="submit" value="Сохранить" class="btn btn-fill modal__form__bottom__submit" data-btn="deleteItem">Удалить клиента</button>
                <button type="button" class="modal__form__bottom__cancel" data-btn="modalClose">Отмена</button>
              </div>
            </form>
          </div>
        `)

        return {element: modal, buttons: modal.querySelectorAll('[data-btn]')}
      },
      contactInput(area, contact) {
        const input = GFCreateFromTemplate(`
          <div class="modal__form__contact modal__form__contacts__element ">
            <table class="modal__form__contact__type">
              <thead data-active="selector" class="modal__form__contact__type__selected">
                <tr>
                </tr>
              </thead>
              <tbody data-active="selector" class="modal__form__contact__type__options"></tbody>
            </table>
            <input class="modal__form__contact__link" data-input="contact" value=''>
          </div>
        `)
        const btnAdd = area.querySelector('.modal__form__contacts__btn')
        const select = input.querySelector('.modal__form__contact__type__selected')
        const options = input.querySelector('.modal__form__contact__type__options')
        const heading = select.querySelector('tr')
        const btnRemove = GFCreateFromTemplate(`<button class="modal__form__contact__x">${SVG.x}</button>`)
        input.append( btnRemove )
        if (contact) {
          heading.dataset.contactType = contact.type
          input.querySelector('[data-input="contact"]').value = contact.value
          optionsList( contact.type )
        } else {
          optionsList()
          heading.dataset.contactType = contactOptions[0].type
          heading.innerHTML = contactOptions[0].name
        }

        document.addEventListener( 'click', (e) => {
          const withinBoundaries = e.composedPath().includes(select);
          if ( ! withinBoundaries ) {
            options.classList.remove('open');
            select.classList.remove('open');
          } else {
            select.classList.toggle('open')
            options.classList.toggle('open')
          }
        })

        btnRemove.addEventListener('click', () => { input.remove() })

        function optionsList(type) {
          contactOptions.forEach(option => {
            if (option.type === type) { heading.innerHTML = option.name }
            const optionItem = GFCreateFromTemplate(`<tr class="${selected(type, option.type)}"><td data-contact-type="${option.type}">${option.name}</td></tr>`)
            optionItem.addEventListener('click', () => {
              heading.innerHTML = option.name
              heading.dataset.contactType = option.type
              area.querySelectorAll('[data-active="selector"]').forEach(selector => { selector.classList.remove('open')})
            })
            function selected(type, value) {if (type == value) {return 'selected'} else {return 'unselected'}}
            options.append(optionItem)
          })
        }
        btnAdd.before(input)
      },
      listItem(object) {
        console.log(object);
        const item = GFCreateFromTemplate(`
          <li class="table__item anim-show" id='personID-${object.id}'>
            <p class='table__item__info table__item__info-add' data-person="id">${object.id}</p>
            <p class='table__item__info' data-person="fullName">${object.surname} ${object.name} ${object.lastName}</p>
            <p class='table__item__info' data-person="create">${object.createString} <span class='table__item__info-add' data-person="createTime">${object.createTimeString.slice(0, 5)}</span> </p>
            <p class='table__item__info' data-person="edit">${object.editString} <span class='table__item__info-add' data-person="editTime">${object.editTimeString.slice(0, 5)}</span> </p>
            <ul class='table__item__info' data-person="contacts" data-target="contacts"> </ul>
            <div class='table__item__info'>
              <button class='btn table__item__btn btn-edit'><span>${SVG.pen}</span> Изменить</button>
              <button class='btn table__item__btn btn-delete' data-target="deleteItem"><span>${SVG.x}</span>Удалить</button>
            </div>
          </li>
        `)

        this.contactList(object.contacts, item.querySelector('[data-target="contacts"]'))
        return {element: item, elementEdit: item.querySelector('.btn-edit'), elementDelete: item.querySelector('[data-target="deleteItem"')}
      },
      contactList(contacts, area) {
        area.innerHTML = ''
        const empty = GFCreateFromTemplate('<span class="table__item__contact-empty">- Пусто -</span> ')
        let list = []

        if (!contacts || contacts.length === 0) { list.push(empty) }
        else {
          empty.remove()
          area.querySelector('.table__item__contact-empty') ? area.querySelector('.table__item__contact-empty').remove() : undefined
          contacts.forEach( contact => {
            const contactParse = contactParser(contact)
            list.push(GFCreateFromTemplate(`<li class="table__item__contact" data-target='itemContact'><a href='${contactParse.link}' target="_blank">${SVG[contact.type] || SVG.men}</a> <span class="table__item__contact__tooltip tooltip"><span class="tooltip__arr"></span><p class="tooltip__text">${contactParse.tooltip}</p></span></li>`))
          })
        }

        if (contacts.length >= 6) {
          area.classList.add('close')
          const btn = GFCreateFromTemplate(`<button class="table__item__contact-btn">+${contacts.length - 4 }</button>`)
          btn.addEventListener('click', () => {
            list[4].remove()
            area.classList.remove('close')
            area.classList.add('open')
            // баг: после удаления 6го элемента, исчезает кнопка и последний элемент
          })

          list.splice(4, 0, btn)
        }

        function contactParser(contact) {
          let link = contact.value
          let tooltip = contact.value
          if (contact.type === 'number') {
            link = `tel:${link}`
            tooltip = `<span>Телефон:</span> <a href="tel:${contact.value}" class='tooltip__link'>${contact.value}</a>`
          } else if ( contact.type === 'numberAdd') {
            link = `tel:${link}`
            tooltip = `<span>Телефон:</span> <a href="tel:${contact.value}" class='tooltip__link'>${contact.value}</a>`
          } else if (contact.type === 'mail') {
            link = `mailto:${link}`
            tooltip = `<span>E-mail:</span> <a target="_blank" href="mailto:${contact.value}" class='tooltip__link'>${contact.value}</a>`
          } else if (contact.type === 'vk') { tooltip = `<span>Вконтакте:</span> <a target="_blank" href="https://vk.com/${contact.value}" class='tooltip__link'>${contact.value}</a>` }
          else if (contact.type === 'fb') { tooltip = `<span>Facebook:</span> <a target="_blank" href="https://www.fb.com/${contact.value}" class='tooltip__link'>${contact.value}</a>` }
          else if (contact.type === 'tw') { tooltip = `<span>Twitter:</span> <a target="_blank" href="https://twitter.com/${contact.value}" class='tooltip__link'>${contact.value}</a>` }
          else { tooltip = `<span>Ссылка:</span> <a target="_blank" href="${contact.value}" class='tooltip__link'>${contact.value}</a>` }

          return {"link": link, "tooltip": tooltip}
        }

        list.forEach(el => {
          area.append(el)
        })
      },
      tableHead(columns) {
        const element = el('.table__element__head')
        const keyActive = {}
        for (const key in columns) {
          if (!Object.hasOwnProperty.call(columns, key)) return
          let column = el('div.table__item__info')
          let name = el('p')
          if (columns[key].name) name.textContent = columns[key].name
          if (columns[key].sorting) column.setAttribute('data-sort', `${columns[key].sorting}`)
          if (columns[key].prompt) {
            const promptElement = el(`span.js-active`, columns[key].prompt)
            const promptActive = columns[key].active()
            keyActive[key] = {}
            keyActive[key].active = columns[key].active(promptElement)
            keyActive[key].btn = column

            column.addEventListener('click', () => {
              promptActive(promptElement)
            }) // сортировка

            name.append(promptElement)
          }
          column.append(name)
          element.append(column)
        }



        return {"element": element, "keys": keyActive}
      },
      listItemEmpty() { return GFCreateFromTemplate(`<li class="table__item-empty" id='personID-empty'>- Список пуст -</li>`) },
      loading() { return GFCreateFromTemplate(`<div class="loading table__loading">${SVG.loadBig}</div>`) },
      tableAdd() { return GFCreateFromTemplate(`<button class='btn btn-empty'><span style="margin-right: 10px;">${SVG.new}</span> Добавить</button>`) },
      tableBody: el('ul.table__element__body'),
    }

    this._run = this._runs()
  }

  _runs() {
    console.log('run');
    this.element = el(`.table__element#${this.id}`)
    this.elementTable = el(`.table__element-table`)
    this.tableHead = this._HTMLTemplates.tableHead(this.columns)
    this.tableBody = this._HTMLTemplates.tableBody
    this.tableAdd = this._HTMLTemplates.tableAdd()
    this.loading = this._HTMLTemplates.loading()
    this.elementTable.append(this.tableHead.element, this.tableBody)
    this.element.append(this.elementTable, this.tableAdd)

    this.tableAdd.addEventListener('click', () => { this.openModalForm()})

    this.listUpdate()

    for (const key in this.tableHead.keys) {
      if (Object.hasOwnProperty.call(this.tableHead.keys, key)) {
        this._sortToggle[key] = true
        this.tableHead.keys[key].btn.addEventListener('click', () => {
          this.tableHead.keys[key].active
          this.sortList(key)
        })
      }
    }
  }


  listUpdate() {
    this.tableBody.innerHTML = ''
    this.tableBody.append(this.loading)
    this.getData().then((data) => {
      console.log(data);
      this.tableBody.innerHTML = ''
      this.data = data

      data.length > 0 ? data.sort(sort('id')).forEach( object => { this.pushListItem(object) }) : this.tableBody.append(this._HTMLTemplates.listItemEmpty())

      this.itemSearch()
      function sort(key) { return (a, b) => a[key] > b[key] ? 1 : -1; }
    })
  }

  pushListItem(object, key) {
    if (document.querySelector('.table__item-empty')) { document.querySelector('.table__item-empty').style.display = 'none' }
    const item = this._HTMLTemplates.listItem(object)

    item.elementEdit.addEventListener('click', () => {
      const ico = item.elementEdit.querySelector('span')
      new Promise((res) => {
        ico.innerHTML = `${SVG.loadSmall}`
        ico.classList.toggle('loading')
        res(api.getClient(object.id))
      }).then(data => {
        ico.innerHTML = `${SVG.pen}`
        ico.classList.toggle('loading')
        this.openModalForm(data)
      })
    })

    item.elementDelete.addEventListener('click', () => { this.openModalDelete(object) })

    this.items.push(item.element)
    this._sortToggle[key] ? this.tableBody.append(item.element) : this.tableBody.prepend(item.element)
  }


  sortList(key) {
    this.data.sort(sort(key))
    this.tableBody.innerHTML = ''
    this.items = []
    this.data.forEach(e => this.pushListItem(e, key))
    this._sortToggle[key] = !this._sortToggle[key]
    function sort(key) { return (a, b) => a[key] > b[key] ? 1 : -1; }
  }



  openModalForm(object) {
    const person = object || {}
    if (!object) { person.name = '', person.surname = '', person.lastName = '' }
    if (document.querySelector(`#modal-${person.id}`)) { document.querySelector(`#modal-${person.id}`).style.display = 'flex'; return }
    if (document.querySelector(`#modal-createPerson`)) { document.querySelector(`#modal-createPerson`).style.display = 'flex'; return }

    const modal = this._HTMLTemplates.modal(person)
    modal.inputs.forEach(input => { input.addEventListener('input', () => { person[input.name] = input.value; })})

    for (const btn in modal.buttons) {
      if (Object.hasOwnProperty.call(modal.buttons, btn)) {
        const button = modal.buttons[btn]
        button.addEventListener('click', (e) => {
          e.preventDefault()
          if (button.dataset.btn === 'modalHidden') { modal.element.style.display = 'none' }
          else if (button.dataset.btn === 'modalClose') { modal.element.remove() }
          else if (button.dataset.btn === 'formSubmit') {
            if (isValid()) {
              person.contacts = []
              modal.element.querySelectorAll(".modal__form__contact").forEach(contact => {
                if (contact.querySelector('input').value.trim()) {
                  person.contacts.push({
                    type: contact.querySelector('tr[data-contact-type]').dataset.contactType,
                    value: contact.querySelector('input').value
                  })
                }
              })
              new Promise((resolve, reject) => {
                button.innerHTML = `<span class="loading" style="margin-right: 5px;">${SVG.loadSmall}</span> Сохранить`
                if (object) {
                  this.itemEdit(object, person, resolve)
                } else {
                  this.itemCreate(person, resolve)
                }
              }).then(() => {
                button.innerHTML = `Сохранить`
                modal.element.remove()
              })
            }
          }
          else if (button.dataset.btn === 'deleteItem') {
            this.openModalDelete(object)
            modal.element.style.display = 'none'
          }
        });
      }
    }

    function isValid() {
      if (modal.validation[0].value.trim() && modal.validation[1].value.trim()) {
        return true
      } else {
        modal.validation.forEach(i => { !i.value.trim() ? i.classList.add('invalid') : undefined })
        modal.error.textContent = 'Ошибка: Заполните обязательные поля'
        modal.error.style.display = 'block'
        return false
      }
    }
    document.body.append(modal.element)
  }
  openModalDelete(object) {
    if (document.querySelector(`#modalDelete-${object.id}`)) { document.querySelector(`#modalDelete-${object.id}`).style.display = 'flex'; return }
    const modal = this._HTMLTemplates.modalDelete(object)

    for (const btn in modal.buttons) {
      if (Object.hasOwnProperty.call(modal.buttons, btn)) {
        modal.buttons[btn].addEventListener('click', (e) => {
          e.preventDefault()
          if (modal.buttons[btn].dataset.btn === 'modalHidden') {
            modal.element.style.display = 'none'
            document.querySelector(`#modal-${object.id}`) ? document.querySelector(`#modal-${object.id}`).style.display = 'flex' : undefined;
          }
          else if (modal.buttons[btn].dataset.btn === 'modalClose') {
            modal.element.remove()
            document.querySelector(`#modal-${object.id}`) ? document.querySelector(`#modal-${object.id}`).style.display = 'flex' : undefined;
          }
          else if (modal.buttons[btn].dataset.btn === 'deleteItem') {
            this.itemDelete(object.id)
            document.querySelector(`#modal-${object.id}`) ? document.querySelector(`#modal-${object.id}`).remove() : undefined;
            modal.element.remove()
          }
        });
      }
    }
    document.body.append(modal.element)
  }

  getData() { return new Promise((res) => { res(api.getList())}).then(data => { return data }) }
  setData() { localStorage.setItem('dataFrontendProSKirill', JSON.stringify(this.data)) }

  itemCreate(object, resolve) {
    new Promise((res, reject) => {
      res(api.createClient(object))
    }).then(data => {
      console.log(data);
      this.data.push(data)
      this.pushListItem(data)
      resolve()
    })
    // this.setData()
  }
  itemEdit(object, objectEdit, resolve) {
    for (const k in object) { if (Object.hasOwnProperty.call(object, k)) { object[k] = objectEdit[k] || object[k]; }}

    return new Promise((res, reject) => {
      res(api.editClient(object))
    }).then(data => {
      this.data[this.data.findIndex(i => i.id === data.id)] = data
      const item = this.items.find(i => i.id === `personID-${data.id}` )
      const itemContactArea = item.querySelector('[data-person="contacts"]')
      item.querySelector('[data-person="fullName"]').innerHTML = `${data.surname} ${data.name} ${data.lastName}`
      item.querySelector('[data-person="edit"]').innerHTML = `${data.editString} <span class='table__item__info-add' data-person="editTime">${data.editTimeString.slice(0, 5)}</span> `
      this._HTMLTemplates.contactList(data.contacts, itemContactArea)
      console.log(item);
      resolve()
    })

    // this.setData()
  }
  itemDelete(id) {
    api.deleteClient(id)
    this.items.find(i => i.id === `personID-${id}`).remove()
    delete this.data.find(i => i.id === id )
    if (!this.items) {
      document.querySelector('.table__item-empty') ? document.querySelector('.table__item-empty').style.display = 'block' : this.tableBody.append(this._HTMLTemplates.listItemEmpty())
    }
    // this.setData()
  }
  itemSearch() {
    this.tableSearch = document.body.querySelector('.header__search')
    this.tableSearch.addEventListener('input', () => {
      setTimeout(() => {
        new Promise((res) => {
          res(api.searchClient( this.tableSearch.value ))
        }).then(data => {
          console.log(data);
          this.items = []
          this.data = data
          this.tableBody.innerHTML = ''
          if (data.length != 0) { data.forEach(e => this.pushListItem(e)) }
          else if (data.length == 0 || elements.length == 0) {
            document.querySelector('.table__item-empty') ? document.querySelector('.table__item-empty').style.display = 'block' : this.tableBody.append(this._HTMLTemplates.listItemEmpty())
          }
        })
      }, 300)
    })
  }
}
