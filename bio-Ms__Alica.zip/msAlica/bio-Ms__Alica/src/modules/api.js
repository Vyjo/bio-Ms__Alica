import { data, clientList } from "./collector";

export const path = {
  server: "http://localhost:3000",
  clients: '/api/clients/',
  search: 'search=',
  testDB: "./testBG.json",
};

export const api = {
  async getList() {
    return new Promise((res, rej) => {
      fetch(path.server + path.clients, { method: 'GET' })
      .then((response) => { res(response.json())})
    })
    .then(data => { return data })
    .catch(error => {
      alert(`Не удалось подключиться к базе. ${error}`)
      return JSON.parse(storage)
    })
    .catch(error => { return error })
  },

  async getClient(id) {
    return new Promise((res, rej) => {
      fetch(path.server + path.clients + id, { method: 'GET' })
      .then((response) => { res(response.json()) })
    })
    .then(data => { return data })
    .catch(error => {
      alert(`Не удалось подключиться к базе. ${error}`)
      return JSON.parse(storage)
    })
    .catch(error => { return error })
  },

  async createClient(object) {
    return new Promise((res, rej) => {
      fetch(path.server + path.clients, {
        method: 'POST',
        body: JSON.stringify(object)
      }).then(response => {
        res(response.json());
      })
    }).then(data => {
      return data
    })
  },

  async editClient(object) {
    return new Promise((res, rej) => {
      fetch(path.server + path.clients + object.id, {
        method: 'PATCH',
        body: JSON.stringify(object)
      }).then(response => {
        res(response.json());
      })
    }).then(data => {
      return data
    })
  },

  async deleteClient(id) {
    fetch(path.server + path.clients + id, { method: 'DELETE' })
    .then(data => { console.log(`удалено ${id}`) })
  },

  async searchClient(value) {
    return new Promise((res, rej) => {
      fetch(path.server + path.clients + `?search=${value}`, { method: 'GET' })
      .then((response) => { res(response.json())})
    })
    .then(data => { return data })
    .catch(error => {
      alert(`Не удалось подключиться к базе. ${error}`)
      return JSON.parse(storage)
    })
    .catch(error => { return error })
  },
}
// const JSONData = JSON.stringify(data)
// sessionStorage.setItem('dataFrontendProSKirill', JSONData)
// localStorage.setItem('dataFrontendProSKirill', JSONData)
// const storage = localStorage.getItem('dataFrontendProSKirill')
