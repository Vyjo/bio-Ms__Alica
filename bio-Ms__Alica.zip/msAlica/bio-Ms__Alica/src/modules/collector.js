/* eslint-disable no-undef */

export const SVG = {
  visa: require("../assets/img/svg/cards/visa.svg"),
  alipay: require("../assets/img/svg/cards/alipay.svg"),
  amex: require("../assets/img/svg/cards/amex.svg"),
  'code-front': require("../assets/img/svg/cards/code-front.svg"),
  code: require("../assets/img/svg/cards/code.svg"),
  diners: require("../assets/img/svg/cards/diners.svg"),
  discover: require("../assets/img/svg/cards/discover.svg"),
  elo: require("../assets/img/svg/cards/elo.svg"),
  generic: require("../assets/img/svg/cards/generic.svg"),
  hiper: require("../assets/img/svg/cards/hiper.svg"),
  hipercard: require("../assets/img/svg/cards/hipercard.svg"),
  jcb: require("../assets/img/svg/cards/jcb.svg"),
  maestro: require("../assets/img/svg/cards/maestro.svg"),
  mastercard: require("../assets/img/svg/cards/mastercard.svg"),
  mir: require("../assets/img/svg/cards/mir.svg"),
  paypal: require("../assets/img/svg/cards/paypal.svg"),
  unionpay: require("../assets/img/svg/cards/unionpay.svg"),
  fb: require("../assets/img/svg/fb.svg"),
  logo: require("../assets/img/svg/logo.svg"),
  number: require("../assets/img/svg/number.svg"),
  number2: require("../assets/img/svg/number2.svg"),
  numberAdd: require("../assets/img/svg/numberAdd.svg"),
  mail: require("../assets/img/svg/mail.svg"),
  add: require("../assets/img/svg/add.svg"),
  addSecondary: require("../assets/img/svg/addSecondary.svg"),
  x: require("../assets/img/svg/x.svg"),
  loadBig: require("../assets/img/svg/loadBig.svg"),
  loadSmall: require("../assets/img/svg/loadSmall.svg"),
  vk: require("../assets/img/svg/vk.svg"),
  new: require("../assets/img/svg/new.svg"),
  arrSmall: require("../assets/img/svg/arrSmall.svg"),
  arrFull: require("../assets/img/svg/arrFull.svg"),
  pen: require("../assets/img/svg/pen.svg"),
  men: require("../assets/img/svg/men.svg"),
  union: require("../assets/img/svg/union.svg"),
};

export const contactOptions = [
  {
    name: 'Телефон',
    type: 'number',
  },
  {
    name: 'Доп. телефон',
    type: 'numberAdd',
  },
  {
    name: 'Email',
    type: 'mail',
  },
  {
    name: 'Vk',
    type: 'vk',
  },
  {
    name: 'Facebook',
    type: 'fb',
  },
  {
    name: 'Другое',
    type: 'other',
  },
]

export const clientList = [
  {
    id: 1,
    surname: "Первый",
    name: "Имя",
    lastName: "Фамильевич",
    fio: 'Первый Имя Фамильевич',
    createdAt: 1667059013400,
    updatedAt: 1667059054400,
    contacts: [
      {
        type: "fb",
        value: "#"
      }
    ]
  },
  {
    id: 2,
    surname: "Третий",
    name: "Имя",
    lastName: "Фамильевич",
    fio: 'Третий Имя Фамильевич',
    createdAt: 1667059014321,
    updatedAt: 1667452014321,
    contacts: [
      {
        type: "vk",
        value: "#"
      }
    ]
  },
  {
    id: 3,
    surname: "Седьмой",
    name: "Имя",
    lastName: "Фамильевич",
    fio: 'Седьмой Имя Фамильевич',
    createdAt: 1667059123456,
    updatedAt: 1667059433456,
    contacts: [
      {
        type: "fb",
        value: "#"
      },
      {
        type: "vk",
        value: "#"
      }
    ]
  },
  {
    id: 4,
    surname: "Яковлев",
    name: "Имя",
    lastName: "Фамильевич",
    fio: 'Яковлев Имя Фамильевич',
    createdAt: 1667059013432,
    updatedAt: 1667059113432,
    contacts: [
      {
        type: "other",
        value: "#"
      }
    ]
  },
  {
    id: 5,
    surname: "Адилов",
    name: "Имя",
    lastName: "Фамильевич",
    fio: 'Адилов Имя Фамильевич',
    createdAt: 1667059011234,
    updatedAt: 1667059011234,
    contacts: [
      {
        type: "other",
        value: "#"
      }
    ]
  },
]
