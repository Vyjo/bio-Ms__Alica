import { el, mount } from "redom";
import { GFCreateFromTemplate } from "../creator";
import logo from "./logo.svg";
import "./header.sass";

export default class HeaderElement {
  constructor(text) {
    this.logo = GFCreateFromTemplate(` <a class="header__logo">${logo}</>`);
    this.text = el("input.header__search", {placeholder: text || "Введите запрос"});
    this._container = el(".container", [this.logo, this.text]);
    this.element = el("header.header", this._container);
  }

  assembly(container = document.body) {
    mount(container, this._container);
  }
}
