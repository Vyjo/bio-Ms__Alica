import { el, mount } from "redom";
import "./main.sass";

export default class MainElement {
  constructor() {
    this.element = el("main.main");
  }

  assembly(container = document.body) {
    mount(container, this.element);
  }
}
