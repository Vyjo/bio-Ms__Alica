const boxes = document.querySelectorAll('.box');

boxes.forEach(box => {
  box.style.backgroundColor = 'purple';
  box.style.width = '300px';
});